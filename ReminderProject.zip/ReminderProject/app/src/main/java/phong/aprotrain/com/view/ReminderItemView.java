package phong.aprotrain.com.view;

import android.widget.ListView;
import android.widget.TextView;

public class ReminderItemView {
//    private TextView

}
